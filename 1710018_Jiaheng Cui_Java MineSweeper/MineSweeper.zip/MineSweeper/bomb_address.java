public class bomb_address {
	public int i,j;

	public bomb_address(int i,int j) {
		this.i=i;
		this.j=j;
	}
}
